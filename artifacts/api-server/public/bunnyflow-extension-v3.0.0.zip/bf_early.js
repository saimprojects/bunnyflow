(function(){
  'use strict';

  // ── 1. CSS ────────────────────────────────────────────────────────────────
  const CSS = `
    [data-bf-hide]{display:none!important;visibility:hidden!important;}
    [data-bf-ban] {display:none!important;}
    [data-bf-locked]{opacity:0.35!important;}
    [data-bf-unlocked]{opacity:1!important;pointer-events:auto!important;cursor:pointer!important;}
    .bf-ov{position:absolute!important;inset:0!important;z-index:2147483647!important;cursor:not-allowed!important;background:transparent!important;}
    .bf-lk{position:absolute!important;right:8px!important;top:50%!important;transform:translateY(-50%)!important;font-size:11px!important;z-index:2147483647!important;pointer-events:none!important;}
  `;
  function inject(){
    if(document.getElementById('__bf__')) return;
    const s=document.createElement('style');
    s.id='__bf__';s.textContent=CSS;
    (document.head||document.documentElement).appendChild(s);
  }
  inject();
  new MutationObserver(inject).observe(document.documentElement,{childList:true});

  // ── 2. addEventListener intercept (block locked model clicks) ─────────────
  const _LP_RE   = /lower.{0,5}priority/i;
  const _FREE_RE = /nano.{0,5}banana|pro.{0,5}imagen/i;
  const _BLOCK   = new Set(['click','mousedown','pointerdown','touchstart','keydown']);
  const _orig = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function(type, handler, opts) {
    if (_BLOCK.has(type)) {
      try {
        const full = (this.textContent || '').trim();
        if (full.length > 2 && full.length < 150 && (_LP_RE.test(full) || _FREE_RE.test(full))) return;
      } catch(e) {}
    }
    return _orig.call(this, type, handler, opts);
  };

  // ─────────────────────────────────────────────────────────────────────────
  // ── 3. GENERATION DETECTION — 4 independent layers ───────────────────────
  // All layers dispatch __bf_gen__ event to bunny_extra.js (isolated world)
  // ─────────────────────────────────────────────────────────────────────────

  var _seen      = new Set();    // URLs we've already counted
  var _baseline  = new Set();    // URLs present on page load (don't charge)
  var _baselined = false;        // true after 3s baseline window

  function _dispatch(type) {
    document.dispatchEvent(new CustomEvent('__bf_gen__', { detail: { type: type, count: 1 } }));
  }

  // Mark existing media as baseline after 3 seconds
  function _buildBaseline() {
    document.querySelectorAll('img,video').forEach(function(el) {
      var src = el.src || el.currentSrc || el.poster || '';
      if (src) { _baseline.add(src); _seen.add(src); }
    });
    _baselined = true;
  }
  setTimeout(_buildBaseline, 3000);
  // Also rebuild baseline on navigation
  window.addEventListener('popstate', function() { _baselined = false; _seen.clear(); _baseline.clear(); setTimeout(_buildBaseline, 3000); });

  // ── Layer A: img/video load events (capture phase = fires for ALL elements) ──
  // Catches every <img> or <video> that loads, regardless of src domain.
  // Only fires after baseline to avoid charging for pre-existing content.
  window.addEventListener('load', function(e) {
    if (!_baselined) return;
    var el = e.target;
    if (!el || !el.tagName) return;
    var tag = el.tagName.toUpperCase();
    if (tag !== 'IMG' && tag !== 'VIDEO') return;

    var src = el.src || el.currentSrc || el.poster || '';
    if (!src || src.startsWith('data:') || src.startsWith('chrome-extension:')) return;
    if (_seen.has(src)) return;
    _seen.add(src);

    // Only count large media (> 200x150) to filter out icons/avatars
    var w = el.naturalWidth  || el.videoWidth  || el.offsetWidth  || 0;
    var h = el.naturalHeight || el.videoHeight || el.offsetHeight || 0;
    if (w < 200 || h < 100) return;

    var type = (tag === 'VIDEO') ? 'video' : 'image';
    _dispatch(type);
  }, true /* capture */);

  // ── Layer B: HTMLImageElement.src property setter intercept ──────────────
  // Catches when React/JS sets el.src = "..." programmatically.
  // Works even before the element is in the DOM.
  (function() {
    var _d = Object.getOwnPropertyDescriptor(HTMLImageElement.prototype, 'src');
    if (!_d || !_d.set) return;
    Object.defineProperty(HTMLImageElement.prototype, 'src', {
      configurable: true,
      get: _d.get,
      set: function(v) {
        if (_baselined && v && typeof v === 'string' && v.length > 20 &&
            !v.startsWith('data:') && !_seen.has(v)) {
          _seen.add(v);
          // Will confirm size via naturalWidth check after load
          var self = this;
          self.addEventListener('load', function onLoad() {
            self.removeEventListener('load', onLoad);
            if ((self.naturalWidth || 0) >= 200 && (self.naturalHeight || 0) >= 100) {
              if (!_baseline.has(v)) _dispatch('image');
            }
          }, { once: true });
        }
        return _d.set.call(this, v);
      }
    });
  })();

  // ── Layer C: HTMLVideoElement.src / poster setter intercept ──────────────
  (function() {
    ['src', 'poster'].forEach(function(prop) {
      var proto = HTMLVideoElement.prototype;
      var _d = Object.getOwnPropertyDescriptor(proto, prop) ||
               Object.getOwnPropertyDescriptor(HTMLMediaElement.prototype, prop);
      if (!_d || !_d.set) return;
      Object.defineProperty(proto, prop, {
        configurable: true,
        get: _d.get,
        set: function(v) {
          if (_baselined && v && typeof v === 'string' && v.length > 20 &&
              !v.startsWith('data:') && !_seen.has(v)) {
            _seen.add(v);
            if (!_baseline.has(v)) _dispatch('video');
          }
          return _d.set.call(this, v);
        }
      });
    });
  })();

  // ── Layer D: PerformanceObserver — catches ALL resources including CSS bg ──
  // This fires for fetch, XHR, img, video, CSS background-image, etc.
  (function() {
    if (typeof PerformanceObserver === 'undefined') return;
    try {
      var _po = new PerformanceObserver(function(list) {
        if (!_baselined) return;
        list.getEntries().forEach(function(entry) {
          var url = entry.name || '';
          if (!url || url.startsWith('data:') || url.startsWith('chrome-extension:')) return;
          if (_seen.has(url)) return;

          // Only care about potential video/image content URLs
          // Match: googleapis.com, googleusercontent.com, lh3, yt, any video extension
          var isMedia = /storage\.googleapis\.com|googleusercontent\.com|\.mp4|\.webm|\.mov|\.jpg|\.jpeg|\.png|\.webp/i.test(url);
          // Also match any fetch/XHR to labs.google that indicates generation
          var isGenAPI = /labs\.google.*\/api\//i.test(url);

          if (!isMedia && !isGenAPI) return;
          if (_baseline.has(url)) return;
          _seen.add(url);

          // Use transferSize or encodedBodySize to filter out tiny resources
          var size = entry.transferSize || entry.encodedBodySize || 0;
          if (size > 0 && size < 10000) return; // < 10KB = not a real video/image

          var type = /\.mp4|\.webm|\.mov|video/i.test(url) ? 'video' : 'image';
          _dispatch(type);
        });
      });
      _po.observe({ type: 'resource', buffered: true });
    } catch(e) {}
  })();

  // ── Layer E: Network intercept (fetch + XHR) ─────────────────────────────
  // Original network intercept — watches API responses for videoUri patterns
  var _BF_FLOW = /labs\.google|googleapis\.com|\/fx\//i;
  var _bf_url = '', _bf_nv = 0, _bf_ni = 0;

  function _bf_reset() {
    if (location.href !== _bf_url) { _bf_url = location.href; _bf_nv = 0; _bf_ni = 0; }
  }

  function _bf_inspect(text) {
    if (!text || text.length < 10 || text.length > 500000) return;
    try {
      _bf_reset();
      var hasV = /videoUri|video_uri|\.mp4|\.webm|generatedVideo|videoUrl/i.test(text);
      var hasI = /imageUri|image_uri|generatedImage|imageUrl/i.test(text);
      if (!hasV && !hasI) return;
      if (hasV) {
        var totalV = Math.min((text.match(/videoUri|video_uri|\.mp4|\.webm|generatedVideo|videoUrl/ig)||[]).length, 8);
        if (totalV > _bf_nv) {
          document.dispatchEvent(new CustomEvent('__bf_gen__', { detail: { type: 'video', count: totalV - _bf_nv } }));
          _bf_nv = totalV;
        }
      }
      if (hasI && !hasV) {
        var totalI = Math.min((text.match(/imageUri|image_uri|generatedImage|imageUrl/ig)||[]).length, 8);
        if (totalI > _bf_ni) {
          document.dispatchEvent(new CustomEvent('__bf_gen__', { detail: { type: 'image', count: totalI - _bf_ni } }));
          _bf_ni = totalI;
        }
      }
    } catch(e) {}
  }

  // fetch
  var _origFetch = window.fetch;
  window.fetch = async function(input, init) {
    var resp;
    try { resp = await _origFetch.call(this, input, init); } catch(e) { throw e; }
    try {
      var url = typeof input === 'string' ? input : (input && input.url) || '';
      if (_BF_FLOW.test(url) && !/fonts|analytics|gtag|signout/i.test(url)) {
        resp.clone().text().then(_bf_inspect).catch(function(){});
      }
    } catch(e) {}
    return resp;
  };

  // XHR
  var _xhrMap = new WeakMap();
  var _xhrOpen = XMLHttpRequest.prototype.open;
  var _xhrSend = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(m, url) {
    _xhrMap.set(this, String(url || ''));
    return _xhrOpen.apply(this, arguments);
  };
  XMLHttpRequest.prototype.send = function() {
    var xhr = this, url = _xhrMap.get(xhr) || '';
    if (_BF_FLOW.test(url) && !/fonts|analytics|gtag|signout/i.test(url)) {
      xhr.addEventListener('load', function() { _bf_inspect(xhr.responseText || ''); }, { once: true });
    }
    return _xhrSend.apply(xhr, arguments);
  };

  // EventSource (SSE)
  var _OrigES = window.EventSource;
  if (_OrigES) {
    window.EventSource = function(url, opts) {
      var es = new _OrigES(url, opts);
      if (_BF_FLOW.test(String(url || ''))) {
        ['message','generation','update','result'].forEach(function(ev) {
          es.addEventListener(ev, function(e) { _bf_inspect(e.data || ''); });
        });
      }
      return es;
    };
    Object.setPrototypeOf(window.EventSource, _OrigES);
  }

})();