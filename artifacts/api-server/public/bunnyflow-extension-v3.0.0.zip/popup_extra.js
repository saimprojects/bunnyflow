// popup_extra.js — plan days + live credit update (v2)
(function(){
  'use strict';

  function showPlanDays(data){
    var el = document.getElementById('plan-days');
    if (!el) return;
    var days = null;
    if (data.daysRemaining != null) days = parseInt(data.daysRemaining);
    else if (data.planExpiresAt) {
      var ms = new Date(data.planExpiresAt).getTime() - Date.now();
      days = Math.max(0, Math.ceil(ms / (1000*60*60*24)));
    }
    if (days === null || isNaN(days)) return;
    el.style.display = 'block';
    if (days === 0)      { el.textContent = '\u26A0 Expires today'; el.classList.add('warn'); }
    else if (days <= 5)  { el.textContent = '\u26A0 ' + days + ' days left'; el.classList.add('warn'); }
    else                 { el.textContent = '\u23F1 ' + days + ' days left'; }
  }

  function showCredits(credits){
    var el = document.getElementById('credits-left');
    if (el && credits != null) el.textContent = parseInt(credits).toLocaleString();
  }

  function showPlan(plan){
    var el = document.getElementById('user-plan');
    if (el && plan) el.textContent = plan.charAt(0).toUpperCase() + plan.slice(1) + ' Plan';
  }

  function fetchFresh(apiBase, token){
    fetch(apiBase + '/auth/me', {
      headers: { Authorization: 'Bearer ' + token }
    })
    .then(function(r){ return r.json(); })
    .then(function(u){
      if (!u) return;
      showCredits(u.credits);
      showPlan(u.plan);
      if (u.planExpiresAt || u.daysRemaining != null) showPlanDays(u);
      if (typeof chrome !== 'undefined' && chrome.storage) {
        var patch = {};
        if (u.credits   != null) patch.credits       = u.credits;
        if (u.plan)              patch.plan           = u.plan;
        if (u.planExpiresAt)     patch.planExpiresAt  = u.planExpiresAt;
        if (u.daysRemaining != null) patch.daysRemaining = u.daysRemaining;
        chrome.storage.local.set(patch);
      }
    })
    .catch(function(){});
  }

  if (typeof chrome !== 'undefined' && chrome.storage) {
    // get(null) = retrieve ALL keys, handles any key name background.js uses
    chrome.storage.local.get(null, function(all) {
      // Stale display first (immediate feedback)
      if (all.credits != null) showCredits(all.credits);
      if (all.plan)            showPlan(all.plan);
      if (all.planExpiresAt || all.daysRemaining != null) showPlanDays(all);

      // Find token and apiBase using all possible key names
      var token   = all.token || all.session || all.sessionToken || all.authToken;
      var apiBase = all.apiBase || all.origin || 'https://flowvideobun.replit.app';

      if (token && apiBase) fetchFresh(apiBase, token);
    });
  }
})();
