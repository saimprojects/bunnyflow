// BunnyFlow Extra v4.3 — addEventListener intercept in bf_early.js = root fix
// This file handles visual cleanup (badge removal) + video hiding
(function () {
  'use strict';

  // ── 1. PERMANENT CSS ─────────────────────────────────────────────────────
  const CSS = `
    [data-bf-hide]{display:none!important;visibility:hidden!important;}
    [data-bf-ban] {display:none!important;}
    [data-bf-locked]{opacity:0.35!important;}
    [data-bf-unlocked]{opacity:1!important;pointer-events:auto!important;cursor:pointer!important;}
    .bf-ov{position:absolute!important;inset:0!important;z-index:2147483647!important;
           cursor:not-allowed!important;background:transparent!important;}
    .bf-lk{position:absolute!important;right:8px!important;top:50%!important;
            transform:translateY(-50%)!important;font-size:11px!important;
            z-index:2147483647!important;pointer-events:none!important;}
  `;
  function injectCSS() {
    if (document.getElementById('__bf__')) return;
    const s = document.createElement('style');
    s.id = '__bf__'; s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }
  injectCSS();
  new MutationObserver(injectCSS).observe(document.documentElement, { childList: true });

  // ── 2. MATCHERS ───────────────────────────────────────────────────────────
  const LOCK_RE  = /veo.*(lite|quality|fast)/i;
  const LP_RE    = /lower.{0,5}priority/i;
  const FREE_RE  = /nano.{0,5}banana|pro.{0,5}imagen|^imagen\b/i;

  const OPT_SEL = '[role="option"],[role="menuitem"],[role="listitem"],li,[tabindex="0"],[tabindex="-1"]';

  function shouldFreeUnlock(txt) {
    if (!txt || txt.length > 120) return false;
    return LP_RE.test(txt) || FREE_RE.test(txt);
  }

  // ── 3. LOCK non-free video models ─────────────────────────────────────────
  function lockModels() {
    document.querySelectorAll(OPT_SEL).forEach(el => {
      if (el.dataset.bfLocked === '1') return;
      const txt = el.textContent || '';
      if (txt.length > 120) return;
      if (LP_RE.test(txt) || FREE_RE.test(txt)) return; // never lock LP/free
      if (!LOCK_RE.test(txt)) return;

      el.dataset.bfLocked = '1';
      el.style.position = 'relative';

      const block = e => { e.stopPropagation(); e.preventDefault(); };
      ['click','mousedown','pointerdown','touchstart','keydown'].forEach(ev =>
        el.addEventListener(ev, block, true));

      if (!el.querySelector('.bf-ov')) {
        const ov = document.createElement('div');
        ov.className = 'bf-ov';
        ov.title = 'BunnyFlow: upgrade to unlock';
        el.appendChild(ov);
      }
      if (!el.querySelector('.bf-lk')) {
        const lk = document.createElement('span');
        lk.className = 'bf-lk'; lk.textContent = '\uD83D\uDD12';
        el.appendChild(lk);
      }
    });
  }

  // ── 4. FORCE-UNLOCK free models (LP + free image models) ─────────────────
  // bf_early.js already prevents persistent_lock.js from adding click-blocking
  // listeners on LP/free elements via addEventListener intercept.
  // This function handles VISUAL cleanup: removes lock badge icons/overlays
  // that persistent_lock.js may still inject as DOM children.

  function removeLockBadges(el) {
    // Remove all children that look like lock overlays or badges:
    // our own .bf-ov / .bf-lk, elements containing 🔒 emoji,
    // elements with "lock"/"overlay" in their class, absolutely positioned overlays
    Array.from(el.children).forEach(child => {
      const childTxt = (child.textContent || '').trim();
      const cls      = (child.className  || '').toLowerCase();
      const isOurs       = child.classList.contains('bf-ov') || child.classList.contains('bf-lk');
      const isLockEmoji  = childTxt === '\uD83D\uDD12' || childTxt === '\uD83D\uDD13';
      const isLockClass  = cls.includes('lock') || cls.includes('overlay');
      const isAbsOverlay = child.style && child.style.position === 'absolute';
      if (isOurs || isLockEmoji || isLockClass || isAbsOverlay) {
        child.remove();
      }
    });
  }

  function unlockFreeModels() {
    document.querySelectorAll(OPT_SEL).forEach(el => {
      const txt = el.textContent || '';
      if (!shouldFreeUnlock(txt)) return;

      // Remove visual lock badges left by persistent_lock.js
      removeLockBadges(el);

      // Force pointer events + visual unlock
      el.style.setProperty('pointer-events', 'auto',    'important');
      el.style.setProperty('opacity',        '1',        'important');
      el.style.setProperty('cursor',         'pointer',  'important');
      delete el.dataset.bfLocked;
      el.removeAttribute('disabled');
      el.removeAttribute('aria-disabled');
      el.dataset.bfUnlocked = '1';
    });
  }

  // ── 5. VIDEO / THUMBNAIL HIDING (home page only) ──────────────────────────
  const DATE_RE = /\b(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)\b.{0,5}\d{1,2}|\d{1,2}:\d{2}\s*(am|pm)|tháng|\d{4}-\d{2}-\d{2}/i;
  const NEWP_RE = /new\s*project|dự án mới|\+\s*d|create new/i;
  const BNNER_RE = /nano banana|is here!|new model|veo\s+\d|imagen/i;

  function isHome() { return !/\/project\//.test(location.pathname); }

  function cardParent(el, depth) {
    depth = depth || 8;
    let cur = el;
    for (let i = 0; i < depth; i++) {
      const p = cur.parentElement;
      if (!p || p === document.body || p === document.documentElement) break;
      if (p.children.length > 6) return cur;
      if (['ARTICLE','LI'].includes(p.tagName) || p.getAttribute('role') === 'gridcell') return p;
      cur = p;
    }
    return cur;
  }

  function hideVideos() {
    if (!isHome()) return;

    // Hide all project card links and their parent cards
    document.querySelectorAll('a[href*="/project/"]').forEach(a => {
      if (a.dataset.bfSeen) return;
      a.dataset.bfSeen = '1';
      if (NEWP_RE.test(a.textContent || '')) return;
      const card = cardParent(a);
      card.dataset.bfHide = '1';
      // Also hide the link itself in case card hiding misses it
      a.dataset.bfHide = '1';
    });

    // Hide list/article/gridcell items that contain dates (project cards)
    document.querySelectorAll('li,article,[role="gridcell"],[role="listitem"]').forEach(el => {
      if (el.dataset.bfSeen) return;
      el.dataset.bfSeen = '1';
      const txt = el.textContent || '';
      if (txt.length > 350 || !DATE_RE.test(txt) || NEWP_RE.test(txt)) return;
      el.dataset.bfHide = '1';
    });

    // Hide any div/section with an image/video AND a date (= project thumbnail card)
    document.querySelectorAll('div,section').forEach(el => {
      if (el.dataset.bfSeen) return;
      const txt = el.textContent || '';
      if (txt.length > 280 || txt.length < 3 || !DATE_RE.test(txt) || NEWP_RE.test(txt)) return;
      if (!el.querySelector('img,video,[role="img"]')) return;
      if (el.querySelectorAll('[data-bf-hide]').length > 0) return;
      el.dataset.bfSeen = '1';
      cardParent(el).dataset.bfHide = '1';
    });

    // Hide "Your projects" / "Recent" section titles and banner ads
    document.querySelectorAll('div,section').forEach(el => {
      if (el.dataset.bfSeen) return;
      const txt = el.textContent || '';
      if (txt.length > 500 || txt.length < 5 || !BNNER_RE.test(txt) || NEWP_RE.test(txt)) return;
      el.dataset.bfSeen = '1';
      el.dataset.bfBan = '1';
    });

    // Also hide any container whose ALL children are [data-bf-hide] (= entire project grid)
    document.querySelectorAll('ul,ol,div[class*="grid"],div[class*="list"]').forEach(el => {
      if (el.dataset.bfSeen) return;
      const kids = Array.from(el.children);
      if (kids.length < 2) return;
      const allHidden = kids.every(k => k.dataset.bfHide === '1' || k.dataset.bfBan === '1');
      if (allHidden) {
        el.dataset.bfSeen = '1';
        el.dataset.bfHide = '1';
      }
    });
  }

  // ── 5b. GENERATION WATCHER & CREDIT DEDUCTION ───────────────────────────────
  // Detects when videos/images complete on Google Flow and calls
  // POST /api/extension/use-credits to deduct from the user's BunnyFlow account.
  //
  // Strategy: track how many <video> elements exist at page-load (baseCount).
  // Any increase after that = new generation completed → charge credits.
  // Images are detected similarly via <img> inside generation result containers.

  // ─── CREDIT DEDUCTION ─────────────────────────────────────────────────────
  // Rules:
  //   • Deduct 20 credits ONLY after a video is SUCCESSFULLY generated.
  //   • Download is FREE — no credits deducted on download.
  //   • Prevent double deductions with a per-page cooldown.
  //
  // Detection approach — two independent layers:
  //   Layer 1 (PRIMARY)  : Progress-bar disappearance watcher in watchGenerations()
  //     Google Flow shows "33%", "67%"... while generating.
  //     When those percentage text elements disappear, generation is complete.
  //   Layer 2 (BACKUP)   : Network intercept in bf_early.js watches API responses
  //     for videoUri / .mp4 patterns and dispatches __bf_gen__ event.
  //
  // Either layer fires callUseCredits() which sends one POST to BunnyFlow backend.
  // Both layers share a cooldown to prevent double charging.
  // ─────────────────────────────────────────────────────────────────────────────

  const _API_BASE = 'https://flowvideobun.replit.app';

  // Cooldown: after any charge, ignore further charge attempts for N ms.
  // Prevents double deduction if both layers fire for the same completion.
  let _chargeTs   = 0;
  const _COOLDOWN = 5000; // 8 seconds per charge event

  // ─── Auth ──────────────────────────────────────────────────────────────────
  // background.js stores sessionToken as "userId:jwt".
  // Extract the real JWT by splitting on the first colon.
  function _extractJwt(all) {
    if (all.sessionToken && typeof all.sessionToken === 'string' && all.sessionToken.includes(':')) {
      const jwt = all.sessionToken.substring(all.sessionToken.indexOf(':') + 1);
      if (jwt && jwt.length > 20) return jwt;
    }
    return all.token || all.session || all.authToken || all.jwt || null;
  }

  // ─── Credit API call ───────────────────────────────────────────────────────
  function callUseCredits(type, count) {
    if (typeof chrome === 'undefined' || !chrome.storage) return;

    // Per-charge cooldown — prevent double deduction
    const now = Date.now();
    if (now - _chargeTs < _COOLDOWN) return;
    _chargeTs = now;

    chrome.storage.local.get(null, function(all) {
      const token   = _extractJwt(all);
      const apiBase = all.apiBase || all.origin || _API_BASE;
      if (!token || token.length < 20) return;

      for (let i = 0; i < (count || 1); i++) {
        fetch(apiBase + '/api/extension/use-credits', {
          method: 'POST',
          headers: {
            'Authorization': 'Bearer ' + token,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ type: type || 'video' }),
        })
        .then(function(res) { return res.ok ? res.json() : null; })
        .then(function(data) {
          if (data && data.creditsRemaining != null && chrome.storage) {
            chrome.storage.local.set({ credits: data.creditsRemaining, creditsLeft: data.creditsRemaining });
          }
        })
        .catch(function() {});
      }
    });

    // Also notify background.js so its own credit path can fire
    if (typeof chrome !== 'undefined' && chrome.runtime) {
      try {
        chrome.runtime.sendMessage({
          type: type === 'video' ? 'VIDEO_GENERATED' : 'IMAGE_GENERATED',
          data: { mediaType: type || 'video', prompt: '', videoUrl: null, thumbnailUrl: null }
        }, function() {});
      } catch(e) {}
    }
  }

  // ─── Layer 2: Network intercept backup ────────────────────────────────────
  // bf_early.js dispatches __bf_gen__ when it finds videoUri in API responses.
  // Use this only if Layer 1 (progress bars) hasn't fired recently.
  document.addEventListener('__bf_gen__', function(e) {
    if (!e.detail || !e.detail.count || e.detail.count <= 0) return;
    callUseCredits(e.detail.type || 'video', e.detail.count);
  });

  // ─── Layer 1: Progress-bar disappearance (PRIMARY) ────────────────────────
  // Counts leaf DOM elements that contain only a percentage number (e.g. "33%").
  // When those disappear after being present → generation completed.
  let _progSeen  = 0; // max % bars seen in current generation run
  let _progPolls = 0; // consecutive polls with % bars visible
  let _genLastUrl = '';

  function countProgressBars() {
    var count = 0;
    var all = document.getElementsByTagName('*');
    for (var i = 0; i < all.length; i++) {
      var el = all[i];
      if (el.childElementCount === 0) {
        var txt = (el.textContent || '').trim();
        // Match only pure percentage text: "33%" "100%" etc.
        if (/^[1-9]\d?%$|^100%$/.test(txt)) count++;
      }
    }
    return count;
  }

  function watchGenerations() {
    if (isHome()) {
      _progSeen = 0; _progPolls = 0; _genLastUrl = '';
      return;
    }

    // Reset counters on page navigation
    if (location.href !== _genLastUrl) {
      _genLastUrl = location.href;
      _progSeen = 0; _progPolls = 0;
      return;
    }

    var current = countProgressBars();

    if (current > 0) {
      // Generation in progress
      if (current > _progSeen) _progSeen = current;
      _progPolls++;

      // Ensure current generation is tracked
      if (!_currGenId || !_genMap[_currGenId]) {
        _currGenId = _newGenId();
        _genMap[_currGenId] = { status: 'pending', deducted: false };
      }
    } else if (_progPolls >= 1 && _progSeen > 0) {
      // Progress bars gone → generation succeeded
      var completed = _progSeen;
      var genId     = _currGenId;
      _progSeen     = 0;
      _progPolls    = 0;

      // Task 2: use tracking — mark success → deduct only once
      if (genId && _genMap[genId] && !_genMap[genId].deducted) {
        _markGenSuccess(genId);
        // If more than 1 video was generating, charge for the rest directly
        for (var extra = 1; extra < completed; extra++) {
          var xId = _newGenId();
          _genMap[xId] = { status: 'pending', deducted: false };
          _markGenSuccess(xId);
        }
      } else {
        // Fallback: no tracking record → charge directly
        callUseCredits('video', completed);
      }

      _currGenId = null;
    }
  }

  // ── MISSING FUNCTIONS (restored) ─────────────────────────────────────────

  // Variable declarations referenced in onNav() and below
  let lpSwitchPending = false;
  let _genBaseVideo   = -1;  // kept for onNav() compat

  // Simple generation tracking: Task 2
  // Each generation gets a unique ID, status, and deducted flag.
  // Only deduct when status = 'success' AND deducted = false.
  const _genMap = {};   // { [genId]: { status, deducted } }
  let   _currGenId = null;

  function _newGenId() {
    return Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  }

  function _markGenSuccess(genId) {
    if (!genId || !_genMap[genId]) return;
    const rec = _genMap[genId];
    if (rec.status === 'success' && rec.deducted) return; // already handled
    rec.status   = 'success';
    if (!rec.deducted) {
      rec.deducted = true;
      callUseCredits('video', 1);
    }
  }

  // autoSelectLP: auto-select "Lower Priority" mode if not already active.
  // Runs every poll — is a no-op if LP is already selected or if on home.
  function autoSelectLP() {
    if (isHome() || lpSwitchPending) return;
    // If the current model button already shows LP, do nothing
    document.querySelectorAll('[role="button"],[role="combobox"],button').forEach(function(btn) {
      const txt = btn.textContent || '';
      if (txt.length > 3 && txt.length < 80 && /lower.{0,5}priority/i.test(txt)) {
        btn.dataset.bfAutoLp = '1'; // mark as already LP
      }
    });
    // If there's a visible model option list, click LP
    document.querySelectorAll('[role="option"],[role="menuitem"],[role="listitem"],li').forEach(function(opt) {
      if (opt.dataset.bfTriedAutoLP || opt.dataset.bfAutoLp) return;
      const txt = opt.textContent || '';
      if (txt.length < 3 || txt.length > 120) return;
      if (!/lower.{0,5}priority/i.test(txt)) return;
      opt.dataset.bfTriedAutoLP = '1';
      try { opt.click(); } catch(e) {}
      lpSwitchPending = true;
      setTimeout(function() { lpSwitchPending = false; }, 2000);
    });
  }

  // hookSendButton: intercept the generate button to record a pending generation ID.
  // On click → create a new gen record with status=pending.
  // watchGenerations() will mark it success when progress bars disappear.
  function hookSendButton() {
    if (isHome()) return;
    const BTN_SEL = '[aria-label*="send" i],[aria-label*="generat" i],[aria-label*="create" i]';
    document.querySelectorAll(BTN_SEL).forEach(function(btn) {
      if (btn.dataset.bfSendHooked) return;
      btn.dataset.bfSendHooked = '1';
      btn.addEventListener('click', function() {
        _currGenId = _newGenId();
        _genMap[_currGenId] = { status: 'pending', deducted: false };
        // Expire old records (keep last 10)
        const keys = Object.keys(_genMap);
        if (keys.length > 10) delete _genMap[keys[0]];
      }, { capture: true });
    });
    // Also hook any form submission (textarea + Enter)
    document.querySelectorAll('textarea,input[type="text"]').forEach(function(inp) {
      if (inp.dataset.bfKeyHooked) return;
      inp.dataset.bfKeyHooked = '1';
      inp.addEventListener('keydown', function(e) {
        if (e.key === 'Enter' && !e.shiftKey) {
          _currGenId = _newGenId();
          _genMap[_currGenId] = { status: 'pending', deducted: false };
        }
      }, { capture: true });
    });
  }

  function run() {
    injectCSS();
    lockModels();
    unlockFreeModels();
    hideVideos();
    autoSelectLP();
    hookSendButton();
    watchGenerations();
  }

  run();
  if (document.readyState !== 'complete') {
    document.addEventListener('DOMContentLoaded', run);
    window.addEventListener('load', run);
  }

  setInterval(run, 200);

  const mo = new MutationObserver(run);
  function startObs() { if (document.body) mo.observe(document.body, { childList: true, subtree: true }); }
  if (document.body) startObs();
  else document.addEventListener('DOMContentLoaded', startObs);

  // SPA navigation
  let last = location.href;
  function onNav() {
    if (location.href === last) return;
    last = location.href;
    // Reset LP auto-select for new page
    lpSwitchPending = false;
    _genBaseVideo = -1;
    _genLastUrl   = '';
    _progSeen     = 0;
    _progPolls    = 0;
    _currGenId    = null;
    document.querySelectorAll('[data-bf-tried-auto-lp],[data-bf-auto-lp],[data-bf-send-hooked]').forEach(el => {
      delete el.dataset.bfTriedAutoLP;
      delete el.dataset.bfAutoLp;
      delete el.dataset.bfSendHooked;
    });
    document.querySelectorAll('[data-bf-seen]').forEach(el => {
      delete el.dataset.bfSeen;
      el.removeAttribute('data-bf-hide');
      el.removeAttribute('data-bf-ban');
    });
    run();
    [100, 300, 600, 1200].forEach(t => setTimeout(run, t));
  }
  window.addEventListener('popstate', onNav);
  window.addEventListener('hashchange', onNav);
  ['pushState','replaceState'].forEach(fn => {
    const orig = history[fn];
    history[fn] = function (...a) { orig.apply(this, a); onNav(); };
  });
  setInterval(onNav, 400);

})();