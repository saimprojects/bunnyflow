// BunnyFlow Whisk Bridge v1.7 — Precise element lock
// Updated: Fixed mouse blocking issue. Removed aggressive corner blocker.
(function () {
  'use strict';

  // ── 1. CSS ────────────────────────────────────────────────────────────────
  var CSS = `
    .__bf_block__ {
      position: fixed !important;
      z-index: 2147483646 !important;
      background: transparent !important;
      cursor: not-allowed !important;
      pointer-events: all !important;
      display: block !important;
    }
    a[href*="discord"] {
      pointer-events: none !important;
      opacity: 0.1 !important;
    }
    /* Hide the account/profile elements completely */
    [aria-label*="Google Account" i], [aria-label*="Account menu" i], img[data-gbid], .gb_A, .gb_B, .gb_d, .gb_Aa, .gb_Ca {
      pointer-events: none !important;
      cursor: not-allowed !important;
      opacity: 0 !important;
      visibility: hidden !important;
    }
  `;

  function injectCSS() {
    var existing = document.getElementById('__bf_whisk_style__');
    if (existing) return;
    var s = document.createElement('style');
    s.id = '__bf_whisk_style__';
    s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }
  injectCSS();

  // ── 2. ELEMENT-LEVEL DIM + LOCK ──────────────────────────────────────────
  var _locked = new WeakSet();
  var _overlays = new Map();

  function _placeOverlay(el) {
    if (_overlays.has(el)) return;
    var ov = document.createElement('div');
    ov.className = '__bf_block__';
    var blk = function(e) { e.stopImmediatePropagation(); e.preventDefault(); };
    ov.addEventListener('click',       blk, true);
    ov.addEventListener('pointerdown', blk, true);
    ov.addEventListener('mousedown',   blk, true);
    (document.body || document.documentElement).appendChild(ov);
    _overlays.set(el, ov);
    _syncOverlay(el, ov);
  }

  function _syncOverlay(el, ov) {
    try {
      var r = el.getBoundingClientRect();
      if (r.width < 1 || r.height < 1) { ov.style.display = 'none'; return; }
      ov.style.display = 'block';
      ov.style.left   = r.left + 'px';
      ov.style.top    = r.top  + 'px';
      ov.style.width  = r.width + 'px';
      ov.style.height = r.height + 'px';
    } catch(_) {}
  }

  function _syncAll() {
    _overlays.forEach(_syncOverlay);
  }

  function dimEl(el) {
    if (!el || _locked.has(el)) return;
    _locked.add(el);
    el.style.setProperty('pointer-events', 'none',        'important');
    el.style.setProperty('opacity',        '0.1',         'important');
    el.style.setProperty('cursor',         'not-allowed', 'important');
    el.style.setProperty('filter',         'grayscale(1) brightness(0.2)', 'important');
    var blk = function(e) { e.stopImmediatePropagation(); e.preventDefault(); };
    el.addEventListener('click',       blk, true);
    el.addEventListener('pointerdown', blk, true);
    _placeOverlay(el);
  }

  function scanAndLock() {
    var ww = window.innerWidth;
    var threshold = ww * 0.55;

    var all = Array.from(document.querySelectorAll(
      'button, a, div[role="button"], span[role="button"], [tabindex="0"], img'
    ));

    all.forEach(function(el) {
      var txt = (el.textContent || '').trim();
      var lbl = (el.getAttribute('aria-label') || '').toLowerCase();
      var href = (el.getAttribute('href') || '');

      if (/my.?library/i.test(txt) || /library/i.test(lbl)) {
        dimEl(el);
        return;
      }

      if (/discord/i.test(href) || /discord/i.test(lbl)) {
        dimEl(el);
        return;
      }

      try {
        var r = el.getBoundingClientRect();
        if (r.width < 1 || r.right < threshold) return;

        if (/ultra/i.test(txt)) { dimEl(el); return; }
        if (txt.length <= 3 && /^[A-Z]{1,3}$/.test(txt)) { dimEl(el); return; }
        if (/account|profile|user|sign.?out|sign.?in/i.test(lbl)) { dimEl(el); return; }
      } catch(_) {}
    });

    document.querySelectorAll('span, div, p').forEach(function(el) {
      if (el.childNodes.length !== 1 || el.childNodes[0].nodeType !== 3) return;
      var own = (el.textContent || '').trim();
      if (!/^ultra$/i.test(own)) return;
      dimEl(el);
      var p = el.parentElement;
      if (p && p !== document.body) { dimEl(p); }
      var gp = p && p.parentElement;
      if (gp && gp !== document.body) { dimEl(gp); }
    });

    _syncAll();
  }

  // ── 3. BOOT ───────────────────────────────────────────────────────────────
  function boot() {
    injectCSS();
    scanAndLock();
  }

  if (document.body) {
    boot();
  } else {
    document.addEventListener('DOMContentLoaded', boot);
  }

  new MutationObserver(function() {
    injectCSS();
    scanAndLock();
  }).observe(document.documentElement, { childList: true, subtree: true });

  setInterval(boot, 200);

  window.addEventListener('scroll', _syncAll, { passive: true, capture: true });
  window.addEventListener('resize', function() { _syncAll(); });

  /* ── Session injection ── */
  var RELOAD_FLAG = '__bf_whisk_reloaded__';
  var RELOAD_TTL  = 15000;

  function injectWhiskSession() {
    var lastReload = Number(localStorage.getItem(RELOAD_FLAG) || 0);
    if (Date.now() - lastReload < RELOAD_TTL) return;

    chrome.storage.local.get(null, function(stored) {
      var authData = stored['__flow_auth__'] || stored['bf_auth'] || null;
      var apiBase  = stored['bf_api_base']   || stored['apiBase'] || 'https://flowbybunny.replit.app';
      if (!authData) return;

      var plan = (authData.plan || 'free').toLowerCase();
      if (plan === 'free') return;

      var token = authData.token || authData.sessionToken || '';
      if (token && token.indexOf(':') !== -1) { token = token.split(':').slice(1).join(':'); }
      if (!token || token.length < 10) return;

      fetch(apiBase + '/api/user/whisk-cookies', {
        headers: { 'Authorization': 'Bearer ' + token }
      }).then(function(resp) {
        if (!resp.ok) return null;
        return resp.json();
      }).then(function(data) {
        if (!data || !data.ok || !data.encryptedCookies) return;
        chrome.runtime.sendMessage({
          type: 'INJECT_WHISK_SESSION',
          encryptedCookies: data.encryptedCookies,
          userId: data.user && data.user.id,
        }, function(response) {
          if (chrome.runtime.lastError) return;
          if (response && response.ok && response.count > 0) {
            try { localStorage.setItem(RELOAD_FLAG, String(Date.now())); } catch(e) {}
            window.location.reload();
          }
        });
      }).catch(function() {});
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectWhiskSession);
  } else {
    injectWhiskSession();
  }
})();
