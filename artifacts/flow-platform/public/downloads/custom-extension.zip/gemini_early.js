// BunnyFlow Gemini Early Lock v1.2
(function () {
  'use strict';

  var CSS = [
    '.sSzDzb, .oZcpUe, .side-nav-list, [jsname="PkMOVf"], [jsname="dsyhDe"], ',
    '[aria-label="Recent conversations"], [aria-label="Hide recent conversations"], ',
    '[data-test-id="history-drawer"], .history-drawer, .side-drawer, bard-sidenav, bard-side-nav, ',
    'mat-drawer.mat-drawer-side, [jscontroller="XD0iqc"] { display: none !important; }',
    '[aria-label*="Google Account" i], [aria-label*="Account menu" i], img[data-gbid], .gb_A, .gb_B, .gb_d, .gb_Aa, .gb_Ca, .gb_Ea, .gb_Ha {',
    '  pointer-events: none !important; cursor: not-allowed !important; opacity: 0 !important; visibility: hidden !important;',
    '}',
    '.bf-gem-lk { color: #ef4444 !important; font-weight: bold !important; font-size: 14px !important; margin-left: 4px; }',
    '.bf-gem-lk::before { content: "⚠️"; }'
  ].join('\n');

  function injectCSS() {
    if (document.getElementById('__bf_gem_css__')) return;
    var s = document.createElement('style');
    s.id = '__bf_gem_css__';
    s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }
  injectCSS();

  function isLockedEl(el) {
    if (!el || el === document.body) return false;
    var lbl = (el.getAttribute('aria-label') || '').toLowerCase();
    if (/account|profile|user|sign.?out/i.test(lbl)) return true;
    if (/recent.?conversations|history/i.test(lbl)) return true;
    return false;
  }

  document.addEventListener('click', function(e) {
    var el = e.target;
    for (var i = 0; i < 5 && el; i++) {
      if (isLockedEl(el)) {
        e.stopImmediatePropagation();
        e.stopPropagation();
        e.preventDefault();
        return;
      }
      el = el.parentElement;
    }
  }, { capture: true });

  setInterval(function() {
    injectCSS();
    document.querySelectorAll('[aria-label*="Account menu" i], [aria-label*="Google Account" i]').forEach(function(el) {
      if (isLockedEl(el) && !el.querySelector('.bf-gem-lk')) {
          var lk = document.createElement('span');
          lk.className = 'bf-gem-lk';
          el.appendChild(lk);
          el.style.opacity = '0.4';
      }
    });
  }, 500);
})();
