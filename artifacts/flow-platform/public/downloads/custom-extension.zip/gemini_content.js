// BunnyFlow Gemini Pro Bridge v1.2 — Strict account and history lock
(function () {
  'use strict';

  // ── 1. CSS: hide conversation history + lock account switcher ──
  const CSS = `
    /* Hide left sidebar / recent conversations history */
    .sSzDzb, .oZcpUe, .side-nav-list,
    [jsname="PkMOVf"], [jsname="dsyhDe"],
    [aria-label="Recent conversations"],
    [aria-label="Hide recent conversations"],
    [data-test-id="history-drawer"],
    .history-drawer, .side-drawer,
    bard-sidenav, bard-side-nav,
    mat-drawer.mat-drawer-side,
    [jscontroller="XD0iqc"],
    c-wiz > div > div.sSzDzb { display: none !important; }

    /* Hide "new chat" / history icon in top bar */
    [mattooltip="Recent conversations"],
    [aria-label="Recent conversations"] { display: none !important; }

    /* Hide the account/profile elements completely */
    [aria-label*="Google Account" i], [aria-label*="Account menu" i], img[data-gbid], .gb_A, .gb_B, .gb_d, .gb_Aa, .gb_Ca, .gb_Ea, .gb_Ha {
      pointer-events: none !important;
      cursor: not-allowed !important;
      opacity: 0 !important;
      visibility: hidden !important;
    }

    /* Unlock all Gemini Pro features - remove any disabled/locked overlays */
    [data-gemini-locked], .upgrade-overlay, .paywall-overlay,
    .upsell-banner, [aria-label*="upgrade"], [aria-label*="Upgrade"] {
      display: none !important;
    }
  `;

  function injectCSS() {
    if (document.getElementById('__bf_gemini_css__')) return;
    const s = document.createElement('style');
    s.id = '__bf_gemini_css__';
    s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }

  injectCSS();
  new MutationObserver(injectCSS).observe(document.documentElement, { childList: true, subtree: true });

  // ── 2. ELEMENT-LEVEL DIM + LOCK ──────────────────────────────────────────
  var _locked = new WeakSet();
  function dimEl(el) {
    if (!el || _locked.has(el)) return;
    _locked.add(el);
    el.style.setProperty('pointer-events', 'none',        'important');
    el.style.setProperty('opacity',        '0',           'important');
    el.style.setProperty('visibility',     'hidden',      'important');
    el.style.setProperty('cursor',         'not-allowed', 'important');
    var blk = function(e) { e.stopImmediatePropagation(); e.preventDefault(); };
    el.addEventListener('click',       blk, true);
    el.addEventListener('pointerdown', blk, true);
  }

  function scanAndLock() {
    var ww = window.innerWidth;
    var all = Array.from(document.querySelectorAll(
      'button, a, div[role="button"], span[role="button"], [tabindex="0"], img'
    ));

    all.forEach(function(el) {
      var lbl = (el.getAttribute('aria-label') || '').toLowerCase();
      var txt = (el.textContent || '').trim();

      // Account / Profile
      if (/account|profile|user|sign.?out|sign.?in/i.test(lbl)) {
        dimEl(el);
        return;
      }

      // History / Recent
      if (/recent.?conversations|history/i.test(lbl)) {
        dimEl(el);
        return;
      }

      // Avatar initials in top right
      if (txt.length <= 3 && /^[A-Z]{1,3}$/.test(txt)) {
          var r = el.getBoundingClientRect();
          if (r.right > ww - 150 && r.top < 100) {
              dimEl(el);
          }
      }
    });
  }

  // ── 3. BOOT ───────────────────────────────────────────────────────────────
  function boot() {
    injectCSS();
    scanAndLock();
  }

  if (document.body) {
    boot();
  } else {
    document.addEventListener('DOMContentLoaded', boot);
  }

  new MutationObserver(function() {
    injectCSS();
    scanAndLock();
  }).observe(document.documentElement, { childList: true, subtree: true });

  setInterval(boot, 500);

  // ── 4. Session injection ──
  const RELOAD_FLAG = '__bf_gemini_reloaded__';
  const RELOAD_TTL  = 15000;

  async function injectGeminiSession() {
    const lastReload = Number(localStorage.getItem(RELOAD_FLAG) || 0);
    if (Date.now() - lastReload < RELOAD_TTL) return;

    let stored = {};
    try { stored = await new Promise(resolve => chrome.storage.local.get(null, resolve)); } catch (e) { return; }

    const authData = stored['__flow_auth__'] || stored['bf_auth'] || null;
    const apiBase  = stored['bf_api_base']   || stored['apiBase'] || 'https://flowbybunny.replit.app';
    if (!authData) return;

    const plan = (authData.plan || 'free').toLowerCase();
    if (plan === 'free') return;

    let token = authData.token || authData.sessionToken || '';
    if (token && token.includes(':')) { token = token.split(':').slice(1).join(':'); }
    if (!token || token.length < 10) return;

    try {
      const resp = await fetch(`${apiBase}/api/user/gemini-cookies`, {
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (!resp.ok) return;
      const data = await resp.json();
      if (!data.ok || !data.encryptedCookies) return;

      chrome.runtime.sendMessage({
        type: 'INJECT_GEMINI_SESSION',
        encryptedCookies: data.encryptedCookies,
        userId: data.user?.id,
      }, (response) => {
        if (chrome.runtime.lastError) return;
        if (response && response.ok && response.count > 0) {
          try { localStorage.setItem(RELOAD_FLAG, String(Date.now())); } catch(e) {}
          window.location.reload();
        }
      });
    } catch (e) { /* ignore */ }
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', injectGeminiSession);
  } else {
    injectGeminiSession();
  }
})();
