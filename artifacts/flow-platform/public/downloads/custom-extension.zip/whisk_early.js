// BunnyFlow Whisk Early Lock v1.4
(function () {
  'use strict';

  var CSS = [
    '.__bf_wh_dim__{',
    '  opacity:0.1!important;pointer-events:none!important;',
    '  cursor:not-allowed!important;filter:grayscale(1) brightness(0.2)!important;',
    '}',
    '[aria-label*="Google Account" i], [aria-label*="Account menu" i], img[data-gbid], .gb_A, .gb_B, .gb_d, .gb_Aa, .gb_Ca, ',
    'button:has(span:contains("ULTRA")), a:has(span:contains("MY LIBRARY")), button:has(div:contains("ULTRA")) {',
    '  pointer-events: none !important; cursor: not-allowed !important; opacity: 0 !important; visibility: hidden !important;',
    '}',
    '.bf-wh-lk { color: #ef4444 !important; font-weight: bold !important; font-size: 14px !important; margin-left: 4px; }',
    '.bf-wh-lk::before { content: "⚠️"; }'
  ].join('\n');

  function injectCSS() {
    if (document.getElementById('__bf_wh_css__')) return;
    var s = document.createElement('style');
    s.id = '__bf_wh_css__';
    s.textContent = CSS;
    (document.head || document.documentElement).appendChild(s);
  }
  injectCSS();

  function isLockedEl(el) {
    if (!el || el === document.body) return false;
    var txt = (el.textContent || '').trim();
    var lbl = (el.getAttribute('aria-label') || '').toLowerCase();
    var href = (el.getAttribute('href') || '');
    if (/my.?library/i.test(txt)) return true;
    if (/ultra/i.test(txt)) return true;
    if (/discord/i.test(href)) return true;
    if (/account|profile|user|sign.?out/i.test(lbl)) return true;
    return false;
  }

  document.addEventListener('click', function(e) {
    var el = e.target;
    for (var i = 0; i < 5 && el; i++) {
      if (isLockedEl(el)) {
        e.stopImmediatePropagation();
        e.stopPropagation();
        e.preventDefault();
        return;
      }
      el = el.parentElement;
    }
  }, { capture: true });

  setInterval(function() {
    injectCSS();
    document.querySelectorAll('button, a, [role="button"]').forEach(function(el) {
      if (isLockedEl(el) && !el.querySelector('.bf-wh-lk')) {
          var lk = document.createElement('span');
          lk.className = 'bf-wh-lk';
          el.appendChild(lk);
          el.style.opacity = '0.4';
      }
    });
  }, 500);
})();
